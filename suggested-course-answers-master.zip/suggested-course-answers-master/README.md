# suggested-course-answers
instruction for the below courses </br>

course:</br>
1.C for Everyone: Structured Programming</br>
2.Object Oriented Programing in java</br>
3.Introduction to SQL</br>
